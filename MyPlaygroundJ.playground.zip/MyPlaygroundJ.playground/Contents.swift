import UIKit

var saludo = "Hola Mundo"

//Juliette
/*juliette
 diseño grafico
 18 años */
let nombre: String = "Juliette"


var peso: Int?
var altura: Int?
var precio: Int?
var edad: Int?

var Peso: Int = 50
var Altura: Int = 155
var Precio: Double = 1000
var Edad: Double = 18

let Nombre = "juliette"
let Apellido = "Ramirez"
var Edad = 18
