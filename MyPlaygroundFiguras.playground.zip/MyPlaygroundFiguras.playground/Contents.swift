import UIKit

var greeting = "Hello, playground"
import Foundation

// Función para calcular el área de un círculo
func calcularAreaDelCirculo(radio: Double) -> Double {
    return Double.pi * radio * radio
}

// Función para calcular el área de un triángulo
func calcularAreaDelTriangulo(base: Double, altura: Double) -> Double {
    return 0.5 * base * altura
}

// Función para calcular el área de un cuadrado
func calcularAreaDelCuadrado(lado: Double) -> Double {
    return lado * lado
}

// Función para calcular el área de un rectángulo
func calcularAreaDelRectangulo(base: Double, altura: Double) -> Double {
    return base * altura
}

// Función para calcular el área de un trapecio
func calcularAreaDelTrapecio(baseMayor: Double, baseMenor: Double, altura: Double) -> Double {
    return 0.5 * (baseMayor + baseMenor) * altura
}

// Ejemplos de uso
let radioCirculo = 5.0
let baseTriangulo = 4.0
let alturaTriangulo = 7.0
let ladoCuadrado = 6.0
let baseRectangulo = 8.0
let alturaRectangulo = 5.0
let baseMayorTrapecio = 6.0
let baseMenorTrapecio = 4.0
let alturaTrapecio = 3.0

let areaCirculo = calcularAreaDelCirculo(radio: radioCirculo)
let areaTriangulo = calcularAreaDelTriangulo(base: baseTriangulo, altura: alturaTriangulo)
let areaCuadrado = calcularAreaDelCuadrado(lado: ladoCuadrado)
let areaRectangulo = calcularAreaDelRectangulo(base: baseRectangulo, altura: alturaRectangulo)
let areaTrapecio = calcularAreaDelTrapecio(baseMayor: baseMayorTrapecio, baseMenor: baseMenorTrapecio, altura: alturaTrapecio)

// Imprimir resultados
print("Área del círculo: \(areaCirculo)")
print("Área del triángulo: \(areaTriangulo)")
print("Área del cuadrado: \(areaCuadrado)")
print("Área del rectángulo: \(areaRectangulo)")
print("Área del trapecio: \(areaTrapecio)")
