import UIKit
//ejercicio1
// en for
for i in 1...10 {
    print (i)
}
//en while
var contador = 1
while contador < 11 {
    print(contador)
    contador += 1
}

//en repeat
var contador2 = 1
repeat {
    print((contador2))
    contador2 += 1
} while contador2 < 11

//ejercicio 2
for i in (1...20) {
    if(i % 2==0 ){
        print (i)
    }
    
}
//ejercicio 3







