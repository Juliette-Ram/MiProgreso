
let numero1 = 7
let numero2 = 11
let suma = numero1 + numero2

print(suma)

let multiplicacion = numero1 * numero2

print (multiplicacion)

let division = numero1 / numero2
print (division)

var nombres: [String] = ["pepe", "Juan", "paco", "moni", "lucy"]
let cantidadNombres = nombres.count
let nombresOrdenados = nombres.sorted()
nombres.append("julio")
nombres.remove(at: 2 )

let a = 6
let b = 3
if ( a > b ) {
    print ("A es mas grande que B")
}

let edad = 18

if edad > 21 {
    print("mayor a 21")
} else {
    print("menor a 21")
}



let numeros = 0
if numeros > 0 {
    print("Numero positivo")
} else if 0 > numeros {
    print("numero negativo")
} else {
    print("El numero es 0")
}

